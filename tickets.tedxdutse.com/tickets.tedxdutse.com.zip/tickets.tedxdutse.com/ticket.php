<?php
require_once 'config.php';
session_start();

if (!isset($_GET['reference'])) {
    header('Location: index.php');
    exit();
}

$reference = $_GET['reference'];
$ticket = getTicketByReference($reference);

if (!$ticket) {
    die('Ticket not found');
}

// If ticket is paid but no QR code exists, generate it
if ($ticket['status'] === 'paid' && empty($ticket['qr_code'])) {
    $qrFilename = 'TEDX_' . $reference . '.png';
    $qrPath = generateQRCode($reference, $qrFilename);
    
    // Update ticket with QR code path
    $stmt = $pdo->prepare("UPDATE tickets SET qr_code = ? WHERE reference = ?");
    $stmt->execute([$qrFilename, $reference]);
    
    // Refresh ticket data
    $ticket = getTicketByReference($reference);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your TEDx Dutse Ticket</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --tedx-red: #e62b1e;
            --tedx-dark: #1a1a1a;
            --shadow-soft: 0 8px 25px rgba(0, 0, 0, 0.1);
            --border-radius: 12px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--tedx-dark);
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            color: white;
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }

        /* Modern Ticket Design */
        .ticket {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-soft);
            overflow: hidden;
            position: relative;
            margin-bottom: 30px;
        }

        .ticket::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, var(--tedx-red) 0%, #ff4757 100%);
        }

        .ticket-header {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 25px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }

        .ticket-header h2 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--tedx-red);
            margin-bottom: 5px;
        }

        .event-info {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 15px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-badge.paid {
            background: #d4edda;
            color: #155724;
        }

        .status-badge.pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-badge.used {
            background: #d1ecf1;
            color: #0c5460;
        }

        .ticket-body {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 25px;
            padding: 25px;
        }

        .ticket-details {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .detail-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: #f8f9fa;
            border-radius: 8px;
            transition: var(--transition);
        }

        .detail-group:hover {
            background: #e9ecef;
        }

        .detail-icon {
            width: 20px;
            text-align: center;
            color: var(--tedx-red);
        }

        .detail-content {
            flex: 1;
        }

        .detail-label {
            font-size: 0.8rem;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 2px;
        }

        .detail-value {
            font-weight: 600;
            color: var(--tedx-dark);
        }

        /* QR Code Section */
        .qr-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            min-width: 180px;
        }

        .qr-code {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 10px;
        }

        .qr-code img {
            max-width: 150px;
            height: auto;
            display: block;
        }

        .qr-info {
            font-size: 0.8rem;
            color: #666;
            text-align: center;
        }

        /* Ticket Footer */
        .ticket-footer {
            background: #f8f9fa;
            padding: 20px 25px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }

        .ticket-footer p {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 10px;
        }

        .reference-code {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: var(--tedx-red);
            background: rgba(230, 43, 30, 0.1);
            padding: 4px 8px;
            border-radius: 4px;
            display: inline-block;
        }

        /* Action Buttons */
        .actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-bottom: 30px;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border: none;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .btn-primary {
            background: var(--tedx-red);
            color: white;
        }

        .btn-secondary {
            background: white;
            color: var(--tedx-dark);
            border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .ticket-body {
                grid-template-columns: 1fr;
                text-align: center;
            }

            .qr-section {
                order: -1;
                margin-bottom: 20px;
            }

            .actions {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }
        }

        @media print {
            body {
                background: white;
                color: black;
            }
            
            .actions, .header {
                display: none;
            }
            
            .ticket {
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Your TEDx Dutse Ticket</h1>
        </div>
        
        <div class="ticket">
            <div class="ticket-header">
                <h2>TEDx Dutse 2024</h2>
                <div class="event-info">
                    <div><i class="fas fa-calendar"></i> September 27, 2025 | 9:00 AM</div>
                    <div><i class="fas fa-map-marker-alt"></i> Banquet hall, Dutse, Jigawa State</div>
                </div>
                <div class="status-badge <?php echo $ticket['status']; ?>">
                    <?php if($ticket['status'] === 'paid'): ?>
                        <i class="fas fa-check-circle"></i> Confirmed
                    <?php elseif($ticket['status'] === 'pending'): ?>
                        <i class="fas fa-clock"></i> Pending
                    <?php else: ?>
                        <i class="fas fa-times-circle"></i> <?php echo ucfirst($ticket['status']); ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="ticket-body">
                <div class="ticket-details">
                    <div class="detail-group">
                        <i class="fas fa-user detail-icon"></i>
                        <div class="detail-content">
                            <div class="detail-label">Name</div>
                            <div class="detail-value"><?php echo htmlspecialchars($ticket['name']); ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-group">
                        <i class="fas fa-envelope detail-icon"></i>
                        <div class="detail-content">
                            <div class="detail-label">Email</div>
                            <div class="detail-value"><?php echo htmlspecialchars($ticket['email']); ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-group">
                        <i class="fas fa-phone detail-icon"></i>
                        <div class="detail-content">
                            <div class="detail-label">Phone</div>
                            <div class="detail-value"><?php echo htmlspecialchars($ticket['phone']); ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-group">
                        <i class="fas fa-ticket-alt detail-icon"></i>
                        <div class="detail-content">
                            <div class="detail-label">Ticket Type</div>
                            <div class="detail-value"><?php echo strtoupper($ticket['ticket_type']); ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-group">
                        <i class="fas fa-money-bill detail-icon"></i>
                        <div class="detail-content">
                            <div class="detail-label">Amount Paid</div>
                            <div class="detail-value">₦<?php echo number_format($ticket['amount'], 2); ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="qr-section">
                    <?php if ($ticket['status'] === 'paid' && $ticket['qr_code'] && file_exists('qr/' . $ticket['qr_code'])): ?>
                        <div class="qr-code">
                            <img src="qr/<?php echo $ticket['qr_code']; ?>" alt="QR Code for <?php echo $ticket['reference']; ?>">
                        </div>
                        <div class="qr-info">
                            <i class="fas fa-qrcode"></i><br>
                            Scan at venue for entry
                        </div>
                    <?php elseif ($ticket['status'] === 'paid'): ?>
                        <div class="qr-code" style="padding: 30px; background: #f8f9fa; border: 2px dashed #ddd;">
                            <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: #ffc107; margin-bottom: 10px;"></i>
                            <p style="color: #666; font-size: 0.9rem;">QR Code Generating...</p>
                            <button onclick="location.reload()" style="margin-top: 10px; padding: 8px 16px; background: var(--tedx-red); color: white; border: none; border-radius: 6px; cursor: pointer;">
                                <i class="fas fa-refresh"></i> Refresh
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="qr-code" style="padding: 30px; background: #fff3cd; border: 2px dashed #ffc107;">
                            <i class="fas fa-clock" style="font-size: 2rem; color: #856404; margin-bottom: 10px;"></i>
                            <p style="color: #856404; font-size: 0.9rem;">Payment Required</p>
                            <p style="color: #856404; font-size: 0.8rem; margin-top: 5px;">QR code will be available after payment</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="ticket-footer">
                <p><strong>Please present this ticket at the venue for admission</strong></p>
                <p>Ticket Reference: <span class="reference-code"><?php echo $ticket['reference']; ?></span></p>
                <p style="margin-top: 10px; font-size: 0.8rem;">
                    <i class="fas fa-calendar"></i> Purchased on <?php echo date('M j, Y g:i A', strtotime($ticket['created_at'])); ?>
                </p>
            </div>
        </div>
        
        <div class="actions">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i>
                Print Ticket
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-plus"></i>
                Buy Another Ticket
            </a>
        </div>
        
        <?php if ($ticket['status'] === 'paid'): ?>
        <div style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); padding: 20px; border-radius: 8px; text-align: center; color: white;">
            <h3 style="margin-bottom: 15px;"><i class="fas fa-info-circle"></i> Important Information</h3>
            <div style="display: grid; gap: 10px; font-size: 0.9rem;">
                <p><i class="fas fa-clock"></i> Doors open at 8:30 AM</p>
                <p><i class="fas fa-id-card"></i> Please bring a valid ID</p>
                <p><i class="fas fa-mobile-alt"></i> Have this QR code ready on your phone</p>
                <p><i class="fas fa-envelope"></i> Check your email for event updates</p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <footer style="text-align: center; padding: 30px; color: rgba(255, 255, 255, 0.8);">
        <p>&copy; 2024 TEDx Dutse. All rights reserved.</p>
    </footer>

    <script>
        // Add some interactive effects
        document.querySelectorAll('.detail-group').forEach(group => {
            group.addEventListener('mouseenter', function() {
                this.style.transform = 'translateX(5px)';
            });
            
            group.addEventListener('mouseleave', function() {
                this.style.transform = 'translateX(0)';
            });
        });

        // Auto-refresh for pending payments
        <?php if ($ticket['status'] === 'pending'): ?>
        setTimeout(function() {
            location.reload();
        }, 30000); // Refresh every 30 seconds for pending payments
        <?php endif; ?>
    </script>
</body>
</html>