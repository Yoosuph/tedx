<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'tedx_ticket');
define('DB_USER', 'root');
define('DB_PASS', '');

// Paystack configuration
define('PAYSTACK_SECRET_KEY', 'sk_test_e481317915421729ecc683a9231a26dd1d1d19c9');
define('PAYSTACK_PUBLIC_KEY', 'pk_test_a5c3558b443441aa030f6879392654506eb972c5');
define('PAYSTACK_BASE_URL', 'https://api.paystack.co');

// Site configuration
define('SITE_URL', 'http://localhost/tickets.tedxdutse.com');

// Create database connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Include functions
require_once 'functions.php';
?>