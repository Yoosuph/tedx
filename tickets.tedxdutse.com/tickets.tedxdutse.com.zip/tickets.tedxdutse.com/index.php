<?php
require_once 'config.php';
session_start();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $ticket_type = $_POST['ticket_type'];
    
    // Validate input
    if (empty($name) || empty($email) || empty($phone)) {
        $error = 'Please fill all required fields';
    } else {
        $amount = ($ticket_type === 'vip') ? 10000 : 3000;
        $reference = 'TEDX' . time() . rand(1000, 9999);
        
        try {
            // Save to database
            $stmt = $pdo->prepare("INSERT INTO tickets (ticket_type, name, email, phone, reference, amount) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$ticket_type, $name, $email, $phone, $reference, $amount]);
            
            // Initialize Paystack payment
            $url = "https://api.paystack.co/transaction/initialize";
            $fields = [
                'email' => $email,
                'amount' => $amount * 100, // Convert to kobo
                'reference' => $reference,
                'callback_url' => SITE_URL . '/verify_payment.php?reference=' . $reference,
                'metadata' => json_encode([
                    'custom_fields' => [
                        [
                            'display_name' => 'Full Name',
                            'variable_name' => 'full_name',
                            'value' => $name
                        ],
                        [
                            'display_name' => 'Phone Number',
                            'variable_name' => 'phone_number',
                            'value' => $phone
                        ],
                        [
                            'display_name' => 'Ticket Type',
                            'variable_name' => 'ticket_type',
                            'value' => $ticket_type
                        ]
                    ]
                ])
            ];
            
            $fields_string = http_build_query($fields);
            
            // Open connection
            $ch = curl_init();
            
            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
                "Cache-Control: no-cache",
            ));
            
            // So that curl_exec returns the contents of the cURL; rather than echoing it
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            // Execute post
            $result = curl_exec($ch);
            $response = json_decode($result, true);
            
            if ($response['status'] && isset($response['data']['authorization_url'])) {
                header('Location: ' . $response['data']['authorization_url']);
                exit();
            } else {
                $error = 'Payment initialization failed. Please try again.';
            }
        } catch (Exception $e) {
            $error = 'An error occurred: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEDx Dutse - Ticket Purchase</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>TEDx Dutse Ticket Purchase</h1>
            <p>Join us for an inspiring event filled with innovative ideas</p>
        </header>
        
        <div class="ticket-form">
            <?php if ($error): ?>
                <div class="alert error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number *</label>
                    <input type="tel" id="phone" name="phone" required>
                </div>
                
                <div class="form-group">
                    <label for="ticket_type">Ticket Type *</label>
                    <select id="ticket_type" name="ticket_type" required>
                        <option value="regular">Regular - ₦3,000</option>
                        <option value="vip">VIP - ₦10,000</option>
                    </select>
                </div>
                
                <button type="submit">Proceed to Payment</button>
            </form>
        </div>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> TEDx Dutse. All rights reserved.</p>
        </footer>
        <div class="recovery-option">
    <p>Didn't save your ticket? <a href="#" id="recoverBtn">Find my ticket here</a></p>
</div>
    </div>

    <!-- Add this modal for ticket recovery -->
<div id="recoverModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Find My Ticket</h2>
        <p>Enter your email address to retrieve your ticket information.</p>
        <form id="recoverForm" method="POST" action="recover_ticket.php">
            <div class="form-group">
                <label for="recover_email">Email Address *</label>
                <input type="email" id="recover_email" name="email" required>
            </div>
            <button type="submit">Find My Ticket</button>
        </form>
    </div>
</div>

<!-- Add this script for the modal -->
<script>
// Get the modal
var modal = document.getElementById("recoverModal");
var btn = document.getElementById("recoverBtn");
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body>
</html>